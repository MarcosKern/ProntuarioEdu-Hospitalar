# Resumo do backlog
152 cards planejados; 14 épicos; 653 checklists; 3393 itens desmarcados. Cobertura: 64 tabelas, 121 FKs, 105 regras e 179 operações HTTP. Nenhum item foi criado no Trello nesta preparação.
| Épico | Cards |
| --- | ---: |
| 01 — Configuração e fundação do backend | 11 |
| 02 — Banco de dados e migrations | 25 |
| 03 — Autenticação e identidade | 11 |
| 04 — Autorização e alocação educacional | 11 |
| 05 — Pacientes, unidades e atendimentos | 10 |
| 06 — Medicamentos, prescrições e MAR | 14 |
| 07 — Assistência de enfermagem | 8 |
| 08 — Escalas e protocolos | 14 |
| 09 — Cirurgia segura | 5 |
| 10 — Maternidade e neonatal | 6 |
| 11 — CME | 13 |
| 12 — Auditoria, segurança e anexos | 8 |
| 13 — Integração com clientes | 6 |
| 14 — Testes, qualidade e entrega | 10 |

Prioridades: P0: 41, P1: 74, P2: 36, P3: 1.

A ordem topológica completa está em cobertura.json. Iniciar por FND-01 e DB-01, fechar decisões de contrato/arquitetura, identidade OIDC e autorização; seguir por cadastro/ensino/alocações, enfermaria e MAR, escalas homologadas, cirurgia/maternidade e CME. Auditoria e segurança acompanham todas as entregas.

Decisões pendentes: FND-01, FND-02, FND-04, DB-02, AUTH-01, AUTH-02, ACL-01, ACL-10, MED-06, MED-08, SCL-01, AUD-02, AUD-04, FND-09, DB-07, MAT-06, CME-00, AUD-07, CLI-01, CLI-04, SCL-14.

Os endpoints /health e /api/v1/me já existem e devem ser revalidados. As demais operações são propostas, não funcionalidades implementadas.
