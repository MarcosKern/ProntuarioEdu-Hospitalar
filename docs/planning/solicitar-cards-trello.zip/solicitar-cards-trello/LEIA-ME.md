# Pasta para solicitar a criação dos cards no Trello

Esta pasta contém o planejamento completo. Não contém importador, não exige chave/token de API e não precisa ser colocada no repositório do backend.

## Como usar

1. Abra uma conversa em que o app Trello esteja conectado e suas ferramentas disponíveis.
2. Anexe o ZIP desta pasta ou seus arquivos. O `backlog.json` é o arquivo principal e inclui descrições e checklists completos dos 152 cards.
3. Copie o conteúdo de `PEDIDO_PARA_TRELLO.md` como mensagem nessa conversa.
4. Acompanhe a criação por épico. Se houver interrupção, peça para continuar conciliando os IDs locais com os cards reais já criados.

## Conteúdo

- [PEDIDO_PARA_TRELLO.md](PEDIDO_PARA_TRELLO.md): pedido pronto para copiar e enviar ao assistente com acesso ao Trello.
- [backlog.json](backlog.json): 152 cards, organização, prioridades, descrições, dependências e checklists.
- [cobertura.json](cobertura.json): rastreabilidade das 64 tabelas e 105 regras.
- [endpoints.json](endpoints.json): contratos das 179 operações HTTP planejadas.
- [RESUMO.md](RESUMO.md): quantidades por épico e prioridade, limitações e decisões.
- [referencias/README.md](referencias/README.md): decisões vigentes e limites das fontes.
- [referencias/prontuarioedu_mysql.sql](referencias/prontuarioedu_mysql.sql): SQL MySQL para consulta; não executar durante a organização do Trello.
- [referencias/arquitetura_mysql.md](referencias/arquitetura_mysql.md): dicionário, fluxos e regras de negócio.
- [referencias/diagramas/relacionamentos_mysql.mmd](referencias/diagramas/relacionamentos_mysql.mmd): relacionamentos do modelo.

## Situação

Os dados são de planejamento. Nenhum item foi criado no Trello pela preparação desta pasta; nenhum ID ou link de card foi inventado. A indisponibilidade das ferramentas na conversa anterior não determina o acesso na nova conversa: o assistente deve verificar novamente.
