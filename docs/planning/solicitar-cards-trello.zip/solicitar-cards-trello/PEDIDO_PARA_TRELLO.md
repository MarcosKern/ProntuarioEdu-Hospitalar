# Criar o backlog no Trello a partir dos arquivos anexados

Quero que você crie os cards planejados no **quadro existente Prontuario Hospitalar** usando o app Trello conectado nesta conversa. Estou autorizando a criação/reutilização das listas, labels, cards e checklists descritos nos arquivos. Não desenvolva o backend e não adicione os artefatos de Trello ao repositório.

## Verificar o destino

1. Liste minhas áreas de trabalho e localize o quadro Prontuario Hospitalar acessível pela integração.
2. Confirme nome e link reais. Se houver ambiguidade ou o quadro não for encontrado, pergunte qual usar; não crie quadro duplicado.
3. Leia as listas, labels e cards existentes antes de criar qualquer item.

## Arquivos e escopo

Use `backlog.json` como fonte operacional. Ele contém 152 cards completos em 14 épicos, 653 checklists e 3.393 itens. Leia também `cobertura.json`, `endpoints.json`, `RESUMO.md` e as referências MySQL para interpretar as regras.

Os IDs como FND-01, AUTH-01 e API-001 são chaves LOCAIS, não IDs do Trello. Os campos trello_id/trello_url nulos e o status de indisponibilidade registram a preparação anterior; substitua-os no relatório de execução somente por respostas reais da integração.

Mantenha as decisões vigentes: MVC Python 3.12/FastAPI, MySQL 8.4, SQLAlchemy/PyMySQL síncrono, Alembic e OAuth2/OIDC externo. A Web continua sem tecnologia escolhida. Não crie autenticação local, seeds automáticos na aplicação ou novas tabelas como se já tivessem aprovação. Os cards de decisão representam lacunas a resolver, não funcionalidades já aprovadas.

## Criar/reutilizar os itens

- Reutilize as seis listas: Backlog, Pronto para desenvolvimento, Em desenvolvimento, Code Review, Em testes e Concluído.
- Reutilize ou crie as labels de domínio e prioridade do manifesto. Não use listas separadas por módulo.
- Preserve o título, a descrição completa, a prioridade, a complexidade, as entidades, as regras, os endpoints e os critérios de aceite de cada card.
- Crie checklists reais no Trello a partir de `checklists`, com os itens desmarcados. Não substitua essas checklists apenas por texto na descrição.
- Registre o ID local em cada card para deduplicação e rastreabilidade. Reconcilie também títulos e escopos já existentes, evitando duplicação semântica.
- Não sobrescreva descrição manual, progresso, responsáveis, datas ou checkboxes concluídos de cards existentes sem resolver a diferença. Não arquive nem exclua itens.
- Não atribua membros ou prazos, pois não foram informados. Não marque trabalho como concluído sem evidência.
- FND-01 e DB-01 ficam inicialmente em Pronto para desenvolvimento para análise; os demais em Backlog conforme o manifesto. Cards de segurança e auditoria acompanham as primeiras entregas.
- Resolva dependências pelos IDs locais e, após confirmar os cards reais, acrescente os respectivos links.

## Execução em lotes

Trabalhe por épico, em lotes pequenos que a integração suporte. Mantenha um registro persistente de ID local → ID/link real e de checklists/itens confirmados. Se houver interrupção, reconcilie o estado remoto antes de continuar. Não reenvie cegamente criações cuja resposta tenha sido perdida.

A autorização acima cobre os itens previstos: não é necessário pedir confirmação para cada card. Pergunte quando houver destino ambíguo, conflito com trabalho existente ou necessidade de mudar o escopo.

## Conferência final

Verifique a cobertura das 64 tabelas, 121 FKs e 105 regras, as 179 operações propostas e as checklists de Swagger/testes apropriadas. Preserve decisões pendentes e registre fontes ausentes; não invente fórmulas clínicas, campos físicos ou informações do provedor.

Apresente nome/link do quadro, quantidades efetivamente criadas e reutilizadas por épico/prioridade, checklists/itens confirmados, dependências críticas e itens pendentes. Diferencie planejamento de criação real. Não afirme sucesso sem resposta do Trello e nunca invente IDs ou links.

Se a integração não estiver disponível nesta nova conversa, informe o bloqueio sem solicitar senha, token ou chave pelo chat e sem alegar que os cards foram criados.
