# Referências do planejamento

O SQL e o documento de arquitetura foram revisados para MySQL 8.4. São fontes para consultar nomes físicos e regras durante a organização dos cards; este pacote não autoriza executar SQL, migrations ou código de aplicação.

Decisões vigentes: MVC em Python 3.12/FastAPI, SQLAlchemy/PyMySQL síncrono, Alembic, OIDC externo RS256; Web sem framework escolhido. Os modos de desenvolvimento/testes e Swagger têm implementação de fundação no projeto original, mas funcionalidades clínicas novas permanecem planejadas.

Não foram fornecidos como fontes independentes verificáveis o levantamento funcional v1.1, a arquitetura ensino/alocações v1.4, o código React original, as fórmulas clínicas completas homologadas e o contrato do provedor real. Os cards de decisão apontam essas lacunas. Nunca tratar campos ou escolhas sugeridas como já aprovados.

A arquitetura contém referências a caminhos do repositório para orientar a implementação futura. Para este pacote, use os arquivos desta pasta como correspondentes ao SQL, ao documento revisado e ao diagrama.

Não há usuários, pacientes ou dados de demonstração a carregar. As regras educacionais catalogadas não substituem homologação clínica ou governança institucional.
